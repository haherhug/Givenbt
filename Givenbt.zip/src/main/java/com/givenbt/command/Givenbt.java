package com.example.givenbt;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.Collection;
import java.util.Map;

public class Givenbt implements ModInitializer {

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register(this::registerCommand);
    }

    private void registerCommand(
            CommandDispatcher<ServerCommandSource> dispatcher,
            net.minecraft.registry.RegistryWrapper.WrapperLookup registryAccess,
            CommandManager.RegistrationEnvironment environment
    ) {
        dispatcher.register(
            CommandManager.literal("givenbt")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.argument("targets", EntityArgumentType.players())
                    .then(CommandManager.argument("item", StringArgumentType.word())
                        .then(CommandManager.argument("enchant", StringArgumentType.word())
                            .then(CommandManager.argument(
                                "level",
                                IntegerArgumentType.integer(1, 255)
                            ).executes(ctx -> {

                                Collection<ServerPlayerEntity> players =
                                    EntityArgumentType.getPlayers(ctx, "targets");

                                String itemId = ctx.getArgument("item", String.class);
                                String enchantId = ctx.getArgument("enchant", String.class);
                                int level = IntegerArgumentType.getInteger(ctx, "level");

                                Item item = Registries.ITEM.get(new Identifier(itemId));
                                if (item == null || item == net.minecraft.item.Items.AIR) {
                                    ctx.getSource().sendError(
                                        Text.literal("Invalid item: " + itemId)
                                    );
                                    return 0;
                                }

                                Enchantment enchantment =
                                    Registries.ENCHANTMENT.get(new Identifier(enchantId));

                                if (enchantment == null) {
                                    ctx.getSource().sendError(
                                        Text.literal("Invalid enchantment: " + enchantId)
                                    );
                                    return 0;
                                }

                                for (ServerPlayerEntity player : players) {
                                    ItemStack stack = new ItemStack(item);
                                    EnchantmentHelper.set(
                                        stack,
                                        Map.of(enchantment, level)
                                    );
                                    player.getInventory().insertStack(stack);
                                }

                                ctx.getSource().sendFeedback(
                                    () -> Text.literal("Gave enchanted item"),
                                    true
                                );

                                return players.size();
                            }))
                        )
                    )
                )
        );
    }
}
